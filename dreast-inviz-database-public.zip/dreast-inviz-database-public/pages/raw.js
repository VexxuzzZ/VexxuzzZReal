export default function handler(req, res) {
  res.setHeader('Content-Type', 'text/plain');
  res.status(200).send('[{"number":"62857734669111","status":"active"}]');
}